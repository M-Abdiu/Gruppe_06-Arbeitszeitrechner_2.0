"""
Business Logik der Zeiterfassungsanwendung.
Vollständig unabhängig von UI und Datenbank.
Alle Regeln, Berechnungen und Validierungen liegen hier.
"""

from typing import List, Tuple
from models import User, Zeiteintrag, Violation

# ─── Fachliche Konstanten ────────────────────────────────────────────────────

WOCHENTAGE: List[str] = ["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag"]
WOCHENENDE: List[str] = ["Samstag", "Sonntag"]

VOLLZEIT_STUNDEN: float = 42.0   # Sollstunden/Woche bei 100 %
MAX_WOCHEN_STUNDEN: float = 48.0  # Gesetzliches Wochenmaximum
MAX_TAG_STUNDEN: float = 9.0      # Maximale Arbeitsstunden pro Tag
MIN_PAUSE_MINUTEN: float = 30.0   # Minimale Pause in Minuten
MIN_PAUSE_AB_STUNDEN: float = 5.5 # Ab dieser Tagesarbeitszeit ist Pause Pflicht


# ─── Hilffunktionen: Zeitkonvertierung ──────────────────────────────────────

def decimal_to_hhmm(decimal: float) -> str:
    """
    Dezimalstunden → HH:MM-String.
    Beispiel: 8.5 → '08:30', 0.0 → '00:00'
    """
    if decimal <= 0.0:
        return "00:00"
    h = int(decimal)
    m = round((decimal - h) * 60)
    if m == 60:
        h += 1
        m = 0
    return f"{h:02d}:{m:02d}"


def hhmm_to_decimal(hhmm: str) -> float:
    """
    HH:MM-String → Dezimalstunden.
    Beispiel: '08:30' → 8.5, '' → 0.0
    """
    if not hhmm or hhmm.strip() in ("", "00:00"):
        return 0.0
    parts = hhmm.strip().split(":")
    if len(parts) != 2:
        return 0.0
    try:
        h = int(parts[0])
        m = int(parts[1])
        if not (0 <= h <= 23 and 0 <= m <= 59):
            return 0.0
        return h + m / 60.0
    except ValueError:
        return 0.0


# ─── TimeEntry-Logik ────────────────────────────────────────────────────────

def is_empty_entry(e: Zeiteintrag) -> bool:
    """Gibt True zurück, wenn kein Zeiteintrag für diesen Tag vorliegt."""
    return (
        e.morgen_beginn == 0.0
        and e.morgen_stop == 0.0
        and e.nachmittag_beginn == 0.0
        and e.nachmittag_stop == 0.0
    )


def is_complete_entry(e: Zeiteintrag) -> bool:
    """
    Prüft, ob der Zeiteintrag fachlich vollständig ist.
    Entweder komplett leer (kein Arbeitstag) oder
    konsistent gefüllt (Beginn + Stop pro Block).
    """
    if is_empty_entry(e):
        return True

    # Morgen gestartet → Morgen Stop muss vorhanden sein
    if e.morgen_beginn > 0 and e.morgen_stop == 0.0:
        return False

    # Nachmittag gestartet → Nachmittag Stop muss vorhanden sein
    if e.nachmittag_beginn > 0 and e.nachmittag_stop == 0.0:
        return False

    # Stop ohne Beginn ist inkonsistent
    if e.morgen_stop > 0 and e.morgen_beginn == 0.0:
        return False

    if e.nachmittag_stop > 0 and e.nachmittag_beginn == 0.0:
        return False

    return True


def validate_time_order(e: Zeiteintrag) -> bool:
    """
    Prüft, ob die Zeitreihenfolge korrekt ist.
    Endzeiten dürfen nicht vor Startzeiten liegen.
    """
    times = [
        (e.morgen_beginn, "Morgen Beginn"),
        (e.morgen_stop, "Morgen Stop"),
        (e.nachmittag_beginn, "Nachmittag Beginn"),
        (e.nachmittag_stop, "Nachmittag Stop"),
    ]

    prev = 0.0
    for val, _ in times:
        if val == 0.0:
            continue
        if val < prev:
            return False
        prev = val
    return True


def calculate_daily_hours(e: Zeiteintrag) -> Tuple[float, float]:
    """
    Berechnet Arbeitszeit und Pausenzeit für einen Tag.
    Gibt (arbeitszeit_h, pausenzeit_h) zurück.
    """
    if is_empty_entry(e):
        return 0.0, 0.0

    work_hours = 0.0
    break_hours = 0.0

    if e.morgen_beginn > 0 and e.morgen_stop > 0:
        work_hours += e.morgen_stop - e.morgen_beginn

    if e.nachmittag_beginn > 0 and e.nachmittag_stop > 0:
        work_hours += e.nachmittag_stop - e.nachmittag_beginn

    if e.morgen_stop > 0 and e.nachmittag_beginn > e.morgen_stop:
        break_hours = e.nachmittag_beginn - e.morgen_stop

    return max(0.0, work_hours), max(0.0, break_hours)


# ─── Verstoß-Prüfung ────────────────────────────────────────────────────────

def check_entry_violations(e: Zeiteintrag) -> List[Violation]:
    """
    Prüft einen einzelnen Tageseintrag auf Regelverstöße.
    Gibt eine Liste von Violation-Objekten zurück.
    """
    violations: List[Violation] = []

    if is_empty_entry(e):
        return []

    # Unvollständiger Eintrag
    if not is_complete_entry(e):
        violations.append(Violation(
            zeiteintrag_id=e.id,
            violation_type="Unvollständiger Eintrag",
            message=f"Zeiteintrag am {e.tag} ist unvollständig (fehlende Start- oder Stopzeit)"
        ))
        return violations  # Weitere Prüfungen nicht sinnvoll

    # Zeitreihenfolge falsch
    if not validate_time_order(e):
        violations.append(Violation(
            zeiteintrag_id=e.id,
            violation_type="Ungültige Zeitreihenfolge",
            message=f"Endzeit liegt vor Startzeit am {e.tag}"
        ))
        return violations

    work_hours, break_hours = calculate_daily_hours(e)

    # Wochenendarbeit
    if e.tag in WOCHENENDE:
        violations.append(Violation(
            zeiteintrag_id=e.id,
            violation_type="Wochenendarbeit",
            message=f"Unerlaubte Arbeit am Wochenende ({e.tag})"
        ))

    # Tagesmaximum überschritten
    if work_hours > MAX_TAG_STUNDEN:
        violations.append(Violation(
            zeiteintrag_id=e.id,
            violation_type="Tagesmaximum",
            message=(
                f"Tagesmaximum überschritten am {e.tag}: "
                f"{work_hours:.2f} h (max. {MAX_TAG_STUNDEN:.0f} h)"
            )
        ))

    # Zu wenig Pause
    break_minutes = break_hours * 60
    if work_hours > MIN_PAUSE_AB_STUNDEN and break_minutes < MIN_PAUSE_MINUTEN:
        violations.append(Violation(
            zeiteintrag_id=e.id,
            violation_type="Zu wenig Pause",
            message=(
                f"Zu wenig Pause am {e.tag}: {break_minutes:.0f} Min "
                f"(mind. {MIN_PAUSE_MINUTEN:.0f} Min bei >{MIN_PAUSE_AB_STUNDEN} h Arbeit)"
            )
        ))

    return violations


# ─── Wochen-Zusammenfassung ─────────────────────────────────────────────────

def get_target_hours(pensum: int) -> float:
    """Berechnet die wöchentlichen Sollstunden anhand des Pensums."""
    return VOLLZEIT_STUNDEN * pensum / 100.0


def get_weekly_summary(user: User, entries: List[Zeiteintrag]) -> dict:
    """
    Berechnet die Wochenzusammenfassung für einen Mitarbeitenden.

    Gibt zurück:
    {
        "effektiv": float,       # Ist-Stunden
        "soll": float,           # Soll-Stunden
        "differenz": float,      # Überstunden (+) / Minusstunden (-)
        "pausen": float,         # Gesamtpausenzeit
        "verletzungen": [...]    # Liste von Violation-Objekten
        "verletzt": bool         # Mindestens ein Verstoß vorhanden
    }
    """
    total_work = 0.0
    total_break = 0.0
    all_violations: List[Violation] = []

    for entry in entries:
        if is_empty_entry(entry):
            continue
        work, pause = calculate_daily_hours(entry)
        total_work += work
        total_break += pause
        all_violations.extend(check_entry_violations(entry))

    target = get_target_hours(user.pensum)
    diff = total_work - target

    # Wochen-Verstoß: wöchentliches Maximum
    max_allowed = MAX_WOCHEN_STUNDEN * user.pensum / 100.0
    if total_work > max_allowed:
        all_violations.append(Violation(
            violation_type="Überstunden (Woche)",
            message=(
                f"Wöchentliches Maximum überschritten: "
                f"{total_work:.2f} h (max. {max_allowed:.2f} h)"
            )
        ))

    return {
        "effektiv": total_work,
        "soll": target,
        "differenz": diff,
        "pausen": total_break,
        "verletzungen": all_violations,
        "verletzt": len(all_violations) > 0,
    }
