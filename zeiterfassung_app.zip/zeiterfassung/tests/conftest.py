"""Pytest-Konfiguration: kein DB-Setup nötig für Unit Tests der Business Logik."""
