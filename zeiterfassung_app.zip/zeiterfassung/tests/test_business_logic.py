"""
Unit Tests für die Business Logik.
Ausführen mit: pytest tests/
"""

import pytest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from models import User, Zeiteintrag, Violation
from business_logic import (
    decimal_to_hhmm,
    hhmm_to_decimal,
    is_empty_entry,
    is_complete_entry,
    validate_time_order,
    calculate_daily_hours,
    check_entry_violations,
    get_target_hours,
    get_weekly_summary,
    WOCHENTAGE,
)


# ─── Fixtures ────────────────────────────────────────────────────────────────

@pytest.fixture
def worker_100():
    """Mitarbeitender mit 100% Pensum."""
    return User(id=1, username="test", vorname="Max", nachname="Test",
                email="t@t.ch", passwort="pw", is_admin=False, pensum=100)


@pytest.fixture
def worker_80():
    """Mitarbeitender mit 80% Pensum."""
    return User(id=2, username="test2", vorname="Mia", nachname="Test",
                email="m@t.ch", passwort="pw", is_admin=False, pensum=80)


@pytest.fixture
def worker_50():
    """Mitarbeitender mit 50% Pensum."""
    return User(id=3, username="test3", vorname="Li", nachname="Test",
                email="l@t.ch", passwort="pw", is_admin=False, pensum=50)


def make_entry(tag="Montag", mb=8.0, ms=12.0, nb=13.0, ns=17.0, uid=1) -> Zeiteintrag:
    """Hilfsfunktion: Erstellt einen Zeiteintrag."""
    return Zeiteintrag(
        id=1, user_id=uid, kalenderwoche=24, jahr=2025,
        tag=tag, morgen_beginn=mb, morgen_stop=ms,
        nachmittag_beginn=nb, nachmittag_stop=ns,
    )


# ─── TC_001: Zeitkonvertierung ────────────────────────────────────────────────

class TestZeitkonvertierung:

    def test_decimal_to_hhmm_ganzeStunden(self):
        """TC_001a: 8.0 → '08:00'"""
        assert decimal_to_hhmm(8.0) == "08:00"

    def test_decimal_to_hhmm_halbeStunde(self):
        """TC_001b: 8.5 → '08:30'"""
        assert decimal_to_hhmm(8.5) == "08:30"

    def test_decimal_to_hhmm_null(self):
        """TC_001c: 0.0 → '00:00'"""
        assert decimal_to_hhmm(0.0) == "00:00"

    def test_hhmm_to_decimal_normal(self):
        """TC_001d: '08:30' → 8.5"""
        assert hhmm_to_decimal("08:30") == 8.5

    def test_hhmm_to_decimal_leer(self):
        """TC_001e: '' → 0.0"""
        assert hhmm_to_decimal("") == 0.0

    def test_hhmm_to_decimal_null(self):
        """TC_001f: '00:00' → 0.0"""
        assert hhmm_to_decimal("00:00") == 0.0


# ─── TC_002: Eintragsvollständigkeit ─────────────────────────────────────────

class TestEintragVollstaendigkeit:

    def test_leerer_eintrag(self):
        """TC_002a: Alle Zeiten 0 = leerer Tag"""
        e = make_entry(mb=0.0, ms=0.0, nb=0.0, ns=0.0)
        assert is_empty_entry(e) is True

    def test_vollstaendiger_morgen_und_nachmittag(self):
        """TC_002b: Morgen + Nachmittag vollständig = complete"""
        e = make_entry(mb=8.0, ms=12.0, nb=13.0, ns=17.0)
        assert is_complete_entry(e) is True

    def test_nur_morgen_vollstaendig(self):
        """TC_002c: Nur Morgen (kein Nachmittag) = vollständig"""
        e = make_entry(mb=8.0, ms=12.0, nb=0.0, ns=0.0)
        assert is_complete_entry(e) is True

    def test_morgen_beginn_ohne_stop(self):
        """TC_002d: Morgen Beginn ohne Stop = unvollständig"""
        e = make_entry(mb=8.0, ms=0.0, nb=0.0, ns=0.0)
        assert is_complete_entry(e) is False

    def test_nachmittag_beginn_ohne_stop(self):
        """TC_002e: Nachmittag Beginn ohne Stop = unvollständig"""
        e = make_entry(mb=8.0, ms=12.0, nb=13.0, ns=0.0)
        assert is_complete_entry(e) is False


# ─── TC_003: Zeitreihenfolge ──────────────────────────────────────────────────

class TestZeitreihenfolge:

    def test_korrekte_reihenfolge(self):
        """TC_003a: Korrekte Zeitreihenfolge = valid"""
        e = make_entry(mb=7.0, ms=12.0, nb=13.0, ns=17.0)
        assert validate_time_order(e) is True

    def test_nachmittag_vor_morgen(self):
        """TC_003b: Nachmittag Beginn < Morgen Stop = invalid"""
        e = make_entry(mb=13.0, ms=17.0, nb=8.0, ns=12.0)
        assert validate_time_order(e) is False

    def test_stop_gleich_beginn(self):
        """TC_003c: Stop == Beginn = gültig (0h gearbeitet)"""
        e = make_entry(mb=8.0, ms=8.0, nb=0.0, ns=0.0)
        assert validate_time_order(e) is True


# ─── TC_004: Tagesarbeitszeit-Berechnung ─────────────────────────────────────

class TestTagesberechnung:

    def test_normale_arbeitszeit(self):
        """TC_004a: 8–12 + 13–17 = 8h Arbeit, 1h Pause"""
        e = make_entry(mb=8.0, ms=12.0, nb=13.0, ns=17.0)
        work, pause = calculate_daily_hours(e)
        assert abs(work - 8.0) < 0.01
        assert abs(pause - 1.0) < 0.01

    def test_nur_morgen(self):
        """TC_004b: 8–12 = 4h Arbeit, 0h Pause"""
        e = make_entry(mb=8.0, ms=12.0, nb=0.0, ns=0.0)
        work, pause = calculate_daily_hours(e)
        assert abs(work - 4.0) < 0.01
        assert abs(pause - 0.0) < 0.01

    def test_leerer_eintrag_null_stunden(self):
        """TC_004c: Leerer Eintrag = 0h Arbeit, 0h Pause"""
        e = make_entry(mb=0.0, ms=0.0, nb=0.0, ns=0.0)
        work, pause = calculate_daily_hours(e)
        assert work == 0.0
        assert pause == 0.0

    def test_halbstunde_pause(self):
        """TC_004d: 7:30–12:00 + 12:30–16:30 = 8.5h Arbeit, 0.5h Pause"""
        e = make_entry(mb=7.5, ms=12.0, nb=12.5, ns=16.5)
        work, pause = calculate_daily_hours(e)
        assert abs(work - 8.5) < 0.01
        assert abs(pause - 0.5) < 0.01


# ─── TC_005: Verstösse ────────────────────────────────────────────────────────

class TestVerstoesse:

    def test_kein_verstoss_normale_woche(self):
        """TC_005a: Normaler Tag ohne Verstoss"""
        e = make_entry(tag="Montag", mb=8.0, ms=12.0, nb=13.0, ns=17.0)
        viols = check_entry_violations(e)
        assert len(viols) == 0

    def test_wochenendarbeit_samstag(self):
        """TC_005b: Samstag-Arbeit = Wochenendarbeit-Verstoss"""
        e = make_entry(tag="Samstag", mb=8.0, ms=12.0, nb=0.0, ns=0.0)
        viols = check_entry_violations(e)
        types = [v.violation_type for v in viols]
        assert "Wochenendarbeit" in types

    def test_tagesmaximum_ueberschritten(self):
        """TC_005c: >9h/Tag = Tagesmaximum-Verstoss"""
        e = make_entry(tag="Montag", mb=7.0, ms=12.0, nb=12.5, ns=18.5)  # 11h
        viols = check_entry_violations(e)
        types = [v.violation_type for v in viols]
        assert "Tagesmaximum" in types

    def test_tagesmaximum_grenzwert_genau(self):
        """TC_005d: Genau 9h = kein Verstoss"""
        e = make_entry(tag="Montag", mb=8.0, ms=12.0, nb=13.0, ns=18.0)  # 9h
        viols = check_entry_violations(e)
        types = [v.violation_type for v in viols]
        assert "Tagesmaximum" not in types

    def test_zu_wenig_pause(self):
        """TC_005e: >5.5h ohne Pause = Verstoss"""
        # 8h Arbeit ohne Mittagspause
        e = Zeiteintrag(
            id=1, user_id=1, kalenderwoche=24, jahr=2025,
            tag="Montag", morgen_beginn=7.0, morgen_stop=15.0,
            nachmittag_beginn=0.0, nachmittag_stop=0.0,
        )
        # morgen_beginn → morgen_stop = 8h, keine Pause
        # Aber calculate_daily_hours: nur morgen, keine pause
        work, pause = calculate_daily_hours(e)
        from business_logic import MIN_PAUSE_AB_STUNDEN, MIN_PAUSE_MINUTEN
        if work > MIN_PAUSE_AB_STUNDEN and pause * 60 < MIN_PAUSE_MINUTEN:
            viols = check_entry_violations(e)
            types = [v.violation_type for v in viols]
            assert "Zu wenig Pause" in types

    def test_unvollstaendiger_eintrag(self):
        """TC_005f: Beginn ohne Stop = Unvollständiger Eintrag"""
        e = make_entry(mb=8.0, ms=0.0, nb=0.0, ns=0.0)
        viols = check_entry_violations(e)
        types = [v.violation_type for v in viols]
        assert "Unvollständiger Eintrag" in types


# ─── TC_006: Wochenübersicht ──────────────────────────────────────────────────

class TestWochenuebersicht:

    def test_sollstunden_100_prozent(self, worker_100):
        """TC_006a: 100% Pensum = 42h Sollstunden"""
        assert get_target_hours(100) == 42.0

    def test_sollstunden_80_prozent(self, worker_80):
        """TC_006b: 80% Pensum = 33.6h Sollstunden"""
        assert abs(get_target_hours(80) - 33.6) < 0.01

    def test_sollstunden_50_prozent(self, worker_50):
        """TC_006c: 50% Pensum = 21h Sollstunden"""
        assert abs(get_target_hours(50) - 21.0) < 0.01

    def test_wochenstunden_korrekt(self, worker_100):
        """TC_006d: 5x 8h/Tag = 40h Wochenstunden"""
        entries = [
            make_entry(tag=t, mb=8.0, ms=12.0, nb=13.0, ns=17.0, uid=1)
            for t in WOCHENTAGE
        ]
        summ = get_weekly_summary(worker_100, entries)
        assert abs(summ["effektiv"] - 40.0) < 0.01

    def test_differenz_minusstunden(self, worker_100):
        """TC_006e: 40h Ist bei 42h Soll = -2h Differenz"""
        entries = [
            make_entry(tag=t, mb=8.0, ms=12.0, nb=13.0, ns=17.0, uid=1)
            for t in WOCHENTAGE
        ]
        summ = get_weekly_summary(worker_100, entries)
        assert abs(summ["differenz"] - (-2.0)) < 0.01

    def test_leere_woche_null_stunden(self, worker_100):
        """TC_006f: Leere Woche = 0h Ist-Zeit"""
        summ = get_weekly_summary(worker_100, [])
        assert summ["effektiv"] == 0.0

    def test_wochenmaximum_verstoss(self, worker_100):
        """TC_006g: >48h/Woche = Überstunden-Verstoss"""
        # 5 Tage × 10.5h = 52.5h (>48h)
        entries = [
            make_entry(tag=t, mb=7.0, ms=12.0, nb=12.5, ns=18.0, uid=1)
            for t in WOCHENTAGE
        ]
        summ = get_weekly_summary(worker_100, entries)
        types = [v.violation_type for v in summ["verletzungen"]]
        assert "Überstunden (Woche)" in types

    def test_kein_verstoss_normale_woche(self, worker_100):
        """TC_006h: Normale 40h-Woche ohne Verstoss"""
        entries = [
            make_entry(tag=t, mb=8.0, ms=12.0, nb=13.0, ns=17.0, uid=1)
            for t in WOCHENTAGE
        ]
        summ = get_weekly_summary(worker_100, entries)
        # 40h ≤ 42h Soll → kein Überstunden-Verstoss
        types = [v.violation_type for v in summ["verletzungen"]]
        assert "Überstunden (Woche)" not in types
