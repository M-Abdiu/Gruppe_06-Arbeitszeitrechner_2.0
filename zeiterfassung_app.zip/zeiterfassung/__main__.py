"""Einstiegspunkt: python -m zeiterfassung"""
from main import main
main()
