"""
Datenbankverbindung und Initialisierung.
"""

from sqlmodel import SQLModel, create_engine, Session

DATABASE_URL = "sqlite:///./zeiterfassung.db"

engine = create_engine(DATABASE_URL, echo=False)


def create_db_and_tables() -> None:
    """Erstellt alle Tabellen, falls sie noch nicht existieren."""
    SQLModel.metadata.create_all(engine)


def get_session() -> Session:
    """Gibt eine neue Datenbank-Session zurück."""
    return Session(engine)
