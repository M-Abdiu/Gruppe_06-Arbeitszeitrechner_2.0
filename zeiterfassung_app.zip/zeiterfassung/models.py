"""
ORM-Modelle für die Zeiterfassungsanwendung.
Basis: SQLModel (kombiniert SQLAlchemy + Pydantic).
"""

from typing import Optional, List
from sqlmodel import SQLModel, Field, Relationship


class User(SQLModel, table=True):
    """
    Basisklasse für alle Benutzer.
    is_admin=True  → Admin-Rolle
    is_admin=False → Worker-Rolle
    pensum: Beschäftigungsgrad in Prozent (z.B. 100, 80, 50)
    """
    __tablename__ = "users"

    id: Optional[int] = Field(default=None, primary_key=True)
    username: str = Field(unique=True, index=True)
    vorname: str
    nachname: str
    email: str
    passwort: str
    is_admin: bool = Field(default=False)
    pensum: int = Field(default=100)  # 10–100 %

    # Beziehung: ein User hat viele Zeiteinträge
    zeiteintraege: List["Zeiteintrag"] = Relationship(back_populates="user")


class Zeiteintrag(SQLModel, table=True):
    """
    Zeiteintrag für einen einzelnen Arbeitstag.
    Zeiten werden als Dezimalstunden gespeichert:
      8.0 = 08:00, 8.5 = 08:30, 17.25 = 17:15
    Wert 0.0 bedeutet: kein Eintrag für diesen Zeitblock.
    """
    __tablename__ = "zeiteintraege"

    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: int = Field(foreign_key="users.id")
    kalenderwoche: int
    jahr: int = Field(default=2025)
    tag: str  # "Montag", "Dienstag", ...

    morgen_beginn: float = Field(default=0.0)
    morgen_stop: float = Field(default=0.0)
    nachmittag_beginn: float = Field(default=0.0)
    nachmittag_stop: float = Field(default=0.0)

    # Beziehungen
    user: Optional[User] = Relationship(back_populates="zeiteintraege")
    violations: List["Violation"] = Relationship(back_populates="zeiteintrag")


class Violation(SQLModel, table=True):
    """
    Modelliert einen fachlichen Regelverstoß.
    Eigenes Objekt — nicht nur ein String.
    """
    __tablename__ = "violations"

    id: Optional[int] = Field(default=None, primary_key=True)
    zeiteintrag_id: Optional[int] = Field(default=None, foreign_key="zeiteintraege.id")
    violation_type: str   # z.B. "Überstunden", "Wochenendarbeit"
    message: str = ""     # Detailbeschreibung

    zeiteintrag: Optional[Zeiteintrag] = Relationship(back_populates="violations")
