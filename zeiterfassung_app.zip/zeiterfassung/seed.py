"""
Seed-Daten: Erstellt Demo-Benutzer und Beispiel-Zeiteinträge.
Wird beim ersten App-Start ausgeführt, falls die DB leer ist.
"""

from sqlmodel import Session, select
from db import engine
from models import User, Zeiteintrag


def seed_data() -> None:
    """Befüllt die Datenbank mit Demo-Daten, falls noch keine Benutzer existieren."""
    with Session(engine) as session:
        existing = session.exec(select(User)).first()
        if existing:
            return  # Daten bereits vorhanden

        # ── Benutzer anlegen ──────────────────────────────────────────────
        admin = User(
            username="admin01",
            vorname="Anna",
            nachname="Meier",
            email="admin@firma.ch",
            passwort="1234",
            is_admin=True,
            pensum=100,
        )

        worker1 = User(
            username="berisha",
            vorname="Linda",
            nachname="Berisha",
            email="l.berisha@firma.ch",
            passwort="1234",
            is_admin=False,
            pensum=100,
        )

        worker2 = User(
            username="musterfrau",
            vorname="Maxine",
            nachname="Musterfrau",
            email="m.musterfrau@firma.ch",
            passwort="1234",
            is_admin=False,
            pensum=80,
        )

        worker3 = User(
            username="hunziker",
            vorname="Mia",
            nachname="Hunziker",
            email="m.hunziker@firma.ch",
            passwort="1234",
            is_admin=False,
            pensum=50,
        )

        worker4 = User(
            username="mustermann",
            vorname="Max",
            nachname="Mustermann",
            email="m.mustermann@firma.ch",
            passwort="1234",
            is_admin=False,
            pensum=100,
        )

        session.add_all([admin, worker1, worker2, worker3, worker4])
        session.commit()
        session.refresh(worker1)
        session.refresh(worker2)
        session.refresh(worker3)
        session.refresh(worker4)

        # ── Zeiteinträge KW 24 ────────────────────────────────────────────
        kw, jahr = 24, 2025

        # Linda Berisha (100%) – Freitag kein Eintrag
        berisha_eintraege = [
            Zeiteintrag(user_id=worker1.id, kalenderwoche=kw, jahr=jahr, tag="Montag",
                        morgen_beginn=7.0, morgen_stop=12.0, nachmittag_beginn=13.0, nachmittag_stop=17.0),
            Zeiteintrag(user_id=worker1.id, kalenderwoche=kw, jahr=jahr, tag="Dienstag",
                        morgen_beginn=7.5, morgen_stop=12.5, nachmittag_beginn=13.0, nachmittag_stop=17.5),
            Zeiteintrag(user_id=worker1.id, kalenderwoche=kw, jahr=jahr, tag="Mittwoch",
                        morgen_beginn=6.75, morgen_stop=11.75, nachmittag_beginn=12.5, nachmittag_stop=16.5),
            Zeiteintrag(user_id=worker1.id, kalenderwoche=kw, jahr=jahr, tag="Donnerstag",
                        morgen_beginn=7.167, morgen_stop=12.167, nachmittag_beginn=13.0, nachmittag_stop=17.333),
        ]

        # Maxine Musterfrau (80%) – alle 5 Tage
        musterfrau_eintraege = [
            Zeiteintrag(user_id=worker2.id, kalenderwoche=kw, jahr=jahr, tag="Montag",
                        morgen_beginn=7.5, morgen_stop=12.0, nachmittag_beginn=12.5, nachmittag_stop=16.5),
            Zeiteintrag(user_id=worker2.id, kalenderwoche=kw, jahr=jahr, tag="Dienstag",
                        morgen_beginn=7.75, morgen_stop=12.0, nachmittag_beginn=12.5, nachmittag_stop=16.65),
            Zeiteintrag(user_id=worker2.id, kalenderwoche=kw, jahr=jahr, tag="Mittwoch",
                        morgen_beginn=7.5, morgen_stop=12.0, nachmittag_beginn=12.5, nachmittag_stop=16.5),
            Zeiteintrag(user_id=worker2.id, kalenderwoche=kw, jahr=jahr, tag="Donnerstag",
                        morgen_beginn=7.667, morgen_stop=12.0, nachmittag_beginn=12.5, nachmittag_stop=16.567),
            Zeiteintrag(user_id=worker2.id, kalenderwoche=kw, jahr=jahr, tag="Freitag",
                        morgen_beginn=7.833, morgen_stop=12.0, nachmittag_beginn=12.5, nachmittag_stop=16.6),
        ]

        # Mia Hunziker (50%) – nur Nachmittag
        hunziker_eintraege = [
            Zeiteintrag(user_id=worker3.id, kalenderwoche=kw, jahr=jahr, tag="Montag",
                        morgen_beginn=0.0, morgen_stop=0.0, nachmittag_beginn=13.0, nachmittag_stop=18.75),
            Zeiteintrag(user_id=worker3.id, kalenderwoche=kw, jahr=jahr, tag="Dienstag",
                        morgen_beginn=0.0, morgen_stop=0.0, nachmittag_beginn=12.5, nachmittag_stop=18.5),
            Zeiteintrag(user_id=worker3.id, kalenderwoche=kw, jahr=jahr, tag="Mittwoch",
                        morgen_beginn=0.0, morgen_stop=0.0, nachmittag_beginn=13.25, nachmittag_stop=17.917),
            Zeiteintrag(user_id=worker3.id, kalenderwoche=kw, jahr=jahr, tag="Donnerstag",
                        morgen_beginn=0.0, morgen_stop=0.0, nachmittag_beginn=13.0, nachmittag_stop=16.5),
            Zeiteintrag(user_id=worker3.id, kalenderwoche=kw, jahr=jahr, tag="Freitag",
                        morgen_beginn=0.0, morgen_stop=0.0, nachmittag_beginn=12.0, nachmittag_stop=16.0),
        ]

        # Max Mustermann (100%) – normale Woche
        mustermann_eintraege = [
            Zeiteintrag(user_id=worker4.id, kalenderwoche=kw, jahr=jahr, tag="Montag",
                        morgen_beginn=7.0, morgen_stop=12.0, nachmittag_beginn=13.0, nachmittag_stop=17.0),
            Zeiteintrag(user_id=worker4.id, kalenderwoche=kw, jahr=jahr, tag="Dienstag",
                        morgen_beginn=7.5, morgen_stop=12.5, nachmittag_beginn=13.0, nachmittag_stop=16.5),
            Zeiteintrag(user_id=worker4.id, kalenderwoche=kw, jahr=jahr, tag="Mittwoch",
                        morgen_beginn=7.75, morgen_stop=12.5, nachmittag_beginn=13.5, nachmittag_stop=17.5),
            Zeiteintrag(user_id=worker4.id, kalenderwoche=kw, jahr=jahr, tag="Donnerstag",
                        morgen_beginn=6.833, morgen_stop=11.85, nachmittag_beginn=12.833, nachmittag_stop=16.933),
            Zeiteintrag(user_id=worker4.id, kalenderwoche=kw, jahr=jahr, tag="Freitag",
                        morgen_beginn=6.0, morgen_stop=11.0, nachmittag_beginn=12.0, nachmittag_stop=17.0),
        ]

        all_entries = (
            berisha_eintraege
            + musterfrau_eintraege
            + hunziker_eintraege
            + mustermann_eintraege
        )
        session.add_all(all_entries)
        session.commit()

        print("✅ Seed-Daten erfolgreich erstellt.")
        print("   Logins: admin01/1234 | berisha/1234 | musterfrau/1234 | hunziker/1234 | mustermann/1234")
